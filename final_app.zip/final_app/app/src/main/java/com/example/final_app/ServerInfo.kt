package com.example.final_app

class ServerInfo {

    companion object { // 환경 설정 값을 저장함. java 의 static과 비슷함
        const val SERVER_IP = "169.254.120.242"



    }
}